foreach(reverse(<>)){
	print $_;
}
